package com.example.jarvis

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.location.Geocoder
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telephony.SmsManager
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import org.json.JSONObject

object CommandProcessor {

    private val mainHandler = Handler(Looper.getMainLooper())

    private val greetings = listOf(
        "Ji Sir, bataiye kya kaam hai.",
        "Haan Sir, hazir hoon.",
        "Sir, batayiye kis cheez ki zaroorat hai."
    )
    private val howAreYou = listOf(
        "Main bilkul theek hoon Sir, ek AI ko aur kya chahiye. Aap sunaiye?",
        "Sab circuits sahi kaam kar rahe hain Sir. Aap kaise hain?"
    )
    private val jokes = listOf(
        "Sir, ek AI doctor ke paas gaya. Doctor ne kaha 'aapko bas restart chahiye'.",
        "Sir, mujhe bugs pasand nahi, isliye main hamesha apna code khud check karta hoon.",
        "Sir, insaan bolte hain time nikalna mushkil hai, mere paas to sirf milliseconds hote hain."
    )
    private val thanksReplies = listOf(
        "Koi baat nahi Sir, yahi to kaam hai mera.",
        "Sir, hamesha hazir hoon aapke liye."
    )
    private val fallback = listOf(
        "Maaf kijiye Sir, wo mere circuits ke bahar tha. Dobara boliye.",
        "Sir, samajh nahi paya. Thoda seedha bol dijiye."
    )

    private fun rand(list: List<String>) = list.random()

    fun process(context: Context, rawText: String, onResult: (String) -> Unit) {
        val text = rawText.trim()
        val lower = text.lowercase(Locale.getDefault())

        try {
            when {
                // ---- small talk ----
                lower.contains("kaise ho") || lower.contains("kaisi ho") ->
                    onResult(rand(howAreYou))

                lower.contains("naam kya") ->
                    onResult("Sir, mera naam Jarvis hai — aapka apna personal assistant.")

                lower.contains("joke") || lower.contains("chutkula") ->
                    onResult(rand(jokes))

                lower.contains("thank") || lower.contains("shukriya") || lower.contains("dhanyawad") ->
                    onResult(rand(thanksReplies))

                lower.contains("hello") || lower == "jarvis" || lower.contains("hey jarvis") ->
                    onResult(rand(greetings))

                // ---- time / date ----
                lower.contains("time") || lower.contains("samay") -> {
                    val t = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
                    onResult("Sir, abhi $t baje hain.")
                }

                lower.contains("date") || lower.contains("tarikh") -> {
                    val d = SimpleDateFormat("d MMMM, yyyy", Locale.getDefault()).format(java.util.Date())
                    onResult("Sir, aaj $d hai.")
                }

                // ---- battery ----
                lower.contains("battery") -> {
                    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                    val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    val comment = if (pct < 20) "Charger dhoond lijiye Sir." else "Sab theek hai."
                    onResult("Sir, battery $pct percent hai. $comment")
                }

                // ---- flashlight ----
                lower.contains("light") || lower.contains("torch") || lower.contains("flash") || lower.contains("flashlight") -> {
                    val turnOn = !(lower.contains("band") || lower.contains("off") || lower.contains("bujha") || lower.contains("close"))
                    val ok = setFlashlight(context, turnOn)
                    if (ok) onResult(if (turnOn) "Ho gaya Sir, roshni ho gayi." else "Sir, light band kar di.")
                    else onResult("Sir, is phone me flash available nahi lag raha.")
                }

                // ---- volume ----
                lower.contains("volume") || lower.contains("awaaz") || lower.contains("sound") -> {
                    val up = lower.contains("badhao") || lower.contains("increase") || lower.contains("tez") ||
                        lower.contains("up") || lower.contains("full")
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI
                    )
                    onResult(if (up) "Volume badha diya Sir." else "Volume kam kar diya Sir.")
                }

                // ---- direct app shortcuts (checked before the generic "kholo" search) ----
                lower.contains("youtube") -> {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    onResult("Sir, YouTube khol raha hoon.")
                }

                lower.contains("chrome") -> {
                    val i = context.packageManager.getLaunchIntentForPackage("com.android.chrome")
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(i)
                        onResult("Sir, Chrome khol raha hoon.")
                    } else {
                        onResult("Sir, Chrome install nahi mila.")
                    }
                }

                lower.contains("camera") -> {
                    val i = Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(i)
                    onResult("Sir, camera khol diya.")
                }

                lower.contains("calculator") -> {
                    val pkgs = listOf(
                        "com.google.android.calculator",
                        "com.sec.android.app.popupcalculator",
                        "com.miui.calculator",
                        "com.android.calculator2"
                    )
                    var opened = false
                    for (pkg in pkgs) {
                        val i = context.packageManager.getLaunchIntentForPackage(pkg)
                        if (i != null) {
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(i)
                            opened = true
                            break
                        }
                    }
                    onResult(if (opened) "Sir, calculator khol raha hoon." else "Sir, calculator nahi mila.")
                }

                // ---- calculator ----
                lower.contains("plus") || lower.contains("minus") || lower.contains("into") ||
                        lower.contains("divide") || lower.contains("jod") || lower.contains("ghata") -> {
                    val result = calculate(lower)
                    if (result != null) onResult("Sir, jawab hai $result.")
                    else onResult(rand(fallback))
                }

                // ---- notes ----
                lower.contains("note kar") || lower.contains("yaad rakh") -> {
                    val marker = if (lower.contains("note kar")) "note kar" else "yaad rakh"
                    val idx = lower.indexOf(marker)
                    val body = text.substring(idx + marker.length)
                        .removePrefix("lo").removePrefix("le").removePrefix("na").trim()
                    if (body.isNotBlank()) {
                        HistoryStore.addNote(context, body)
                        onResult("Note kar liya Sir: \"$body\"")
                    } else {
                        onResult("Sir, note me kya likhna hai wo to boliye.")
                    }
                }

                // ---- location ----
                lower.contains("kaha hoon") || lower.contains("location") || lower.contains("jagah") -> {
                    getCity(context) { city ->
                        if (city != null) onResult("Sir, aap abhi $city ke aas-paas hain.")
                        else onResult("Sir, location abhi pata nahi kar paya — GPS on hai na check kar lijiye.")
                    }
                }

                // ---- weather ----
                lower.contains("mausam") || lower.contains("weather") -> {
                    getWeather(context) { desc ->
                        onResult(desc ?: "Sir, mausam ki jaankari abhi nahi mil payi — internet check kar lijiye.")
                    }
                }

                // ---- google search ----
                lower.contains("search karo") || lower.contains("google pe") || lower.contains("google kar") -> {
                    val query = extractAfterAny(text, listOf("search karo", "google pe", "google kar", "search"))
                    if (query.isNotBlank()) {
                        val uri = Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8"))
                        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        onResult("Sir, \"$query\" search kar raha hoon.")
                    } else {
                        onResult("Sir, kya search karna hai wo batayiye.")
                    }
                }

                // ---- SMS ----
                (lower.contains("message") || lower.contains("sms")) && lower.contains(" ko ") -> {
                    val name = text.substringBefore(" ko ").trim()
                    val body = extractAfterAny(text, listOf("bhejo", "karo", "send"))
                    val number = lookupContact(context, name)
                    when {
                        number == null -> onResult("Sir, \"$name\" contact me nahi mila.")
                        body.isBlank() -> onResult("Sir, message me kya likhna hai?")
                        else -> {
                            val sent = sendSms(context, number, body)
                            onResult(if (sent) "Sir, $name ko message bhej diya." else "Sir, message bhejne me dikkat aa gayi — SMS permission check kar lijiye.")
                        }
                    }
                }

                // ---- whatsapp ----
                lower.contains("whatsapp") && lower.contains(" ko ") -> {
                    val name = text.substringBefore(" ko ").trim()
                    val body = extractAfterAny(text, listOf("bhejo", "karo", "send"))
                    val number = lookupContact(context, name)
                    if (number == null) {
                        onResult("Sir, \"$name\" contact me nahi mila.")
                    } else {
                        val uri = Uri.parse("https://wa.me/$number?text=" + URLEncoder.encode(body, "UTF-8"))
                        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        onResult("Sir, WhatsApp khol diya $name ke naam, message likha hua hai — bas Send dabana hoga.")
                    }
                }

                // ---- call ----
                lower.contains("call") && lower.contains(" ko ") -> {
                    val name = text.substringBefore(" ko ").trim()
                    val number = lookupContact(context, name)
                    if (number == null) {
                        onResult("Sir, \"$name\" contact me nahi mila.")
                    } else {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        onResult("Sir, $name ka number dial kar raha hoon — call button dabaiye.")
                    }
                }

                // ---- open app ----
                lower.contains("kholo") || lower.contains("khol do") -> {
                    val appName = text.replace("kholo", "", true).replace("khol do", "", true).trim()
                    val opened = openApp(context, appName)
                    onResult(if (opened) "Ji Sir, $appName khol raha hoon." else "Sir, \"$appName\" naam ka app nahi mila.")
                }

                else -> onResult(rand(fallback))
            }
        } catch (e: Exception) {
            onResult("Sir, ek chhoti si dikkat aa gayi — dobara try kijiye.")
        }
    }

    // ---------- helpers ----------

    private fun extractAfterAny(text: String, markers: List<String>): String {
        val lower = text.lowercase(Locale.getDefault())
        var bestIdx = -1
        var bestMarker = ""
        for (m in markers) {
            val idx = lower.lastIndexOf(m)
            if (idx > bestIdx) { bestIdx = idx; bestMarker = m }
        }
        if (bestIdx < 0) return ""
        return text.substring(bestIdx + bestMarker.length).trim()
    }

    private fun calculate(lower: String): Double? {
        val numbers = Regex("-?\\d+(\\.\\d+)?").findAll(lower).map { it.value.toDouble() }.toList()
        if (numbers.size < 2) return null
        val a = numbers[0]; val b = numbers[1]
        return when {
            lower.contains("plus") || lower.contains("jod") -> a + b
            lower.contains("minus") || lower.contains("ghata") -> a - b
            lower.contains("into") -> a * b
            lower.contains("divide") -> if (b != 0.0) a / b else null
            else -> null
        }
    }

    private fun setFlashlight(context: Context, on: Boolean): Boolean {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, on)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun lookupContact(context: Context, name: String): String? {
        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        ) ?: return null
        cursor.use {
            if (it.moveToFirst()) {
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return it.getString(numIdx).replace(" ", "").replace("-", "")
            }
        }
        return null
    }

    private fun sendSms(context: Context, number: String, body: String): Boolean {
        return try {
            val sms = context.getSystemService(SmsManager::class.java)
            sms.sendTextMessage(number, null, body, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun openApp(context: Context, appName: String): Boolean {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        val match = resolveInfos.firstOrNull {
            it.loadLabel(pm).toString().contains(appName, ignoreCase = true)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }

    private fun getCity(context: Context, callback: (String?) -> Unit) {
        Thread {
            var result: String? = null
            try {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if (loc != null) {
                    val geocoder = Geocoder(context, Locale.getDefault())
                    @Suppress("DEPRECATION")
                    val addresses = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)
                    result = addresses?.firstOrNull()?.locality
                        ?: addresses?.firstOrNull()?.subAdminArea
                }
            } catch (e: Exception) {
                result = null
            }
            mainHandler.post { callback(result) }
        }.start()
    }

    private fun getWeather(context: Context, callback: (String?) -> Unit) {
        Thread {
            var result: String? = null
            try {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if (loc != null) {
                    val url = URL(
                        "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current_weather=true"
                    )
                    val conn = url.openConnection() as HttpURLConnection
                    conn.connectTimeout = 6000
                    conn.readTimeout = 6000
                    val json = JSONObject(conn.inputStream.bufferedReader().readText())
                    val current = json.getJSONObject("current_weather")
                    val temp = current.getDouble("temperature")
                    result = "Sir, abhi temperature ${temp.toInt()} degree Celsius hai."
                    conn.disconnect()
                }
            } catch (e: Exception) {
                result = null
            }
            mainHandler.post { callback(result) }
        }.start()
    }
}
