package com.example.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(val you: String, val jarvis: String, val time: Long)
data class NoteEntry(val text: String, val time: Long)

object HistoryStore {

    private const val PREFS = "jarvis_prefs"
    private const val KEY_HISTORY = "history"
    private const val KEY_NOTES = "notes"
    private const val MAX_ENTRIES = 60

    fun addHistory(context: Context, you: String, jarvis: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_HISTORY, "[]"))
        val entry = JSONObject()
        entry.put("you", you)
        entry.put("jarvis", jarvis)
        entry.put("time", System.currentTimeMillis())
        arr.put(entry)
        while (arr.length() > MAX_ENTRIES) arr.remove(0)
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    fun getHistory(context: Context): List<HistoryEntry> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_HISTORY, "[]"))
        val list = mutableListOf<HistoryEntry>()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            list.add(HistoryEntry(o.getString("you"), o.getString("jarvis"), o.getLong("time")))
        }
        return list
    }

    fun addNote(context: Context, text: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_NOTES, "[]"))
        val entry = JSONObject()
        entry.put("text", text)
        entry.put("time", System.currentTimeMillis())
        arr.put(entry)
        prefs.edit().putString(KEY_NOTES, arr.toString()).apply()
    }

    fun getNotes(context: Context): List<NoteEntry> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_NOTES, "[]"))
        val list = mutableListOf<NoteEntry>()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            list.add(NoteEntry(o.getString("text"), o.getLong("time")))
        }
        return list
    }
}
