package com.example.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator

class EdgeGlowView(context: Context) : View(context) {

    private var alphaFraction = 0f
    private var animator: ValueAnimator? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4FB6FF")
        style = Paint.Style.STROKE
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, paint)
    }

    fun start() {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0.35f, 1f).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                alphaFraction = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stop() {
        animator?.cancel()
        animator = null
        alphaFraction = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (alphaFraction <= 0f) return

        val w = width.toFloat()
        val h = height.toFloat()
        val thickness = 22f

        paint.strokeWidth = thickness
        paint.alpha = (alphaFraction * 200).toInt()
        paint.setShadowLayer(28f, 0f, 0f, Color.parseColor("#4FB6FF"))

        val inset = thickness / 2f
        canvas.drawLine(0f, inset, w, inset, paint)          // top
        canvas.drawLine(0f, h - inset, w, h - inset, paint)  // bottom
        canvas.drawLine(inset, 0f, inset, h, paint)           // left
        canvas.drawLine(w - inset, 0f, w - inset, h, paint)   // right
    }
}
