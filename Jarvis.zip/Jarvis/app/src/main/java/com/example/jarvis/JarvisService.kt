package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import java.util.Locale

class JarvisService : Service() {

    private enum class State { WAKE_LISTEN, AWAITING_COMMAND, BUSY }

    private lateinit var windowManager: WindowManager
    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private var glowView: EdgeGlowView? = null
    private var state = State.WAKE_LISTEN
    private var ttsReady = false

    private val handler = Handler(Looper.getMainLooper())
    private val channelId = "jarvis_channel"
    private val notifId = 2001

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(notifId, buildNotification())

        try {
            updateNotification("Jarvis start ho raha hai...")

            setupTts()
            addGlowOverlay()

            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                updateNotification("Mic permission nahi mili")
                stopSelf()
                return
            }

            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                updateNotification("Is phone me speech recognition available nahi hai")
                return
            }

            updateNotification("Recognizer ban raha hai...")
            recognizer = SpeechRecognizer.createSpeechRecognizer(applicationContext)
            recognizer.setRecognitionListener(listener)
            handler.postDelayed({
                speak("Jarvis on ho gaya Sir, main sun raha hoon.") {
                    startWakeListening()
                }
            }, 800)
        } catch (e: Throwable) {
            updateNotification("CRASH: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        runCatching { recognizer.destroy() }
        runCatching { tts.stop(); tts.shutdown() }
        glowView?.let { runCatching { windowManager.removeView(it) } }
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openPending)
            .build()
        nm.notify(notifId, notif)
    }

    // ---------- Notification ----------

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openPending)
            .build()
    }

    // ---------- Glow overlay ----------

    private fun addGlowOverlay() {
        try {
            val view = EdgeGlowView(this)
            glowView = view
            val overlayType =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.START
            windowManager.addView(view, params)
        } catch (e: Exception) {
            glowView = null // overlay permission not granted - voice still works, just no visual glow
        }
    }

    // ---------- TTS ----------

    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts.language = Locale("hi", "IN")
                tts.setSpeechRate(0.95f)
                tts.setPitch(0.92f)
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                handler.post { onSpeakingDone() }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handler.post { onSpeakingDone() }
            }
        })
    }

    private var pendingAfterSpeak: (() -> Unit)? = null

    private fun speak(text: String, after: (() -> Unit)? = null) {
        pendingAfterSpeak = after
        if (ttsReady) {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            audioManager.setStreamVolume(
                android.media.AudioManager.STREAM_MUSIC,
                (audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) * 0.85).toInt(),
                0
            )
            val params = Bundle()
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_utt")
        } else {
            handler.postDelayed({ onSpeakingDone() }, 200)
        }
    }

    private fun onSpeakingDone() {
        val after = pendingAfterSpeak
        pendingAfterSpeak = null
        after?.invoke()
    }

    private fun vibrate() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    // ---------- Recognition ----------

    private fun wakeIntent(): Intent {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        return i
    }

    private fun commandIntent(): Intent {
        val i = wakeIntent()
        // Tuned pause timing so it neither cuts off mid-sentence nor waits too long
        i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1100)
        i.putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1100)
        i.putExtra("android.speech.extra.SPEECH_INPUT_MINIMUM_LENGTH_MILLIS", 1500)
        return i
    }

    private var attemptId = 0
    private var readyReceived = false

    private val wakeAliases = listOf("jarvis", "jervis", "jarviss", "jarvish", "jar vis", "jar vice", "service")

    private fun levenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                dp[i][j] = if (a[i - 1] == b[j - 1]) dp[i - 1][j - 1]
                else 1 + minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
            }
        }
        return dp[a.length][b.length]
    }

    private fun isWakeWord(lower: String): Boolean {
        if (wakeAliases.any { lower.contains(it) }) return true
        // catch other close misrecognitions word-by-word (e.g. "jaarvis", "garvis")
        return lower.split(" ").any { word ->
            word.length >= 4 && levenshtein(word, "jarvis") <= 2
        }
    }

    private var maxRmsThisAttempt = -100f

    private fun startWakeListening() {
        state = State.WAKE_LISTEN
        glowView?.stop()
        readyReceived = false
        maxRmsThisAttempt = -100f
        val myAttempt = ++attemptId
        try {
            recognizer.cancel()
            recognizer.startListening(wakeIntent())
            updateNotification("Listening shuru (attempt $myAttempt)...")
        } catch (e: Exception) {
            updateNotification("Listen error: ${e.message}")
        }
        handler.postDelayed({
            if (myAttempt == attemptId && !readyReceived && state == State.WAKE_LISTEN) {
                updateNotification("Stuck tha (attempt $myAttempt) — recognizer restart kar raha hoon...")
                recreateRecognizerAndRetry()
            }
        }, 4000)
    }

    private fun recreateRecognizerAndRetry() {
        runCatching { recognizer.stopListening() }
        runCatching { recognizer.destroy() }
        recognizer = SpeechRecognizer.createSpeechRecognizer(applicationContext)
        recognizer.setRecognitionListener(listener)
        startWakeListening()
    }

    private fun startCommandListening() {
        state = State.AWAITING_COMMAND
        runCatching {
            recognizer.cancel()
            recognizer.startListening(commandIntent())
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            updateNotification("Sun raha hoon...")
        }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {
            if (rmsdB > maxRmsThisAttempt) maxRmsThisAttempt = rmsdB
        }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {
            // Intentionally ignored - only final results trigger anything,
            // so it never activates on a half-finished sentence.
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            val name = when (error) {
                SpeechRecognizer.ERROR_NETWORK -> "NETWORK"
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "NETWORK_TIMEOUT"
                SpeechRecognizer.ERROR_NO_MATCH -> "NO_MATCH"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "SPEECH_TIMEOUT"
                SpeechRecognizer.ERROR_AUDIO -> "AUDIO"
                SpeechRecognizer.ERROR_CLIENT -> "CLIENT"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "NO_PERMISSION"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "BUSY"
                SpeechRecognizer.ERROR_SERVER -> "SERVER"
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> "LANGUAGE_NOT_SUPPORTED"
                else -> "UNKNOWN($error)"
            }
            if (name != "NO_MATCH" && name != "SPEECH_TIMEOUT") {
                updateNotification("Error: $name")
            } else {
                updateNotification("Kuch suna nahi ($name) — dobara try ho raha hai")
            }
            HistoryStore.addHistory(this@JarvisService, "[$state] error (max audio level: ${"%.1f".format(maxRmsThisAttempt)})", name)
            when (state) {
                State.WAKE_LISTEN -> {
                    if (name == "BUSY") {
                        handler.postDelayed({ recreateRecognizerAndRetry() }, 350)
                    } else {
                        handler.postDelayed({ startWakeListening() }, 350)
                    }
                }
                State.AWAITING_COMMAND -> {
                    state = State.BUSY
                    speak("Sir, sun nahi paya. 'Hey Jarvis' bolke dobara try kijiye.") {
                        glowView?.stop()
                        startWakeListening()
                    }
                }
                State.BUSY -> {}
            }
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull()?.trim() ?: ""
            updateNotification(if (text.isBlank()) "Kuch samajh nahi aaya" else "Suna: \"$text\"")
            val lower = text.lowercase(Locale.getDefault())

            when (state) {
                State.WAKE_LISTEN -> {
                    if (isWakeWord(lower)) {
                        state = State.BUSY
                        vibrate()
                        glowView?.start()
                        speak("Ji Sir.") { startCommandListening() }
                    } else {
                        startWakeListening()
                    }
                }
                State.AWAITING_COMMAND -> {
                    state = State.BUSY
                    if (text.isBlank()) {
                        speak("Sir, sun nahi paya, dobara boliye.") { glowView?.stop(); startWakeListening() }
                    } else {
                        CommandProcessor.process(this@JarvisService, text) { response ->
                            HistoryStore.addHistory(this@JarvisService, text, response)
                            speak(response) { glowView?.stop(); startWakeListening() }
                        }
                    }
                }
                State.BUSY -> {}
            }
        }
    }
}
