package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import java.util.Locale

class JarvisService : Service() {

    private enum class State { WAKE_LISTEN, AWAITING_COMMAND, BUSY }

    private lateinit var windowManager: WindowManager
    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private var glowView: EdgeGlowView? = null
    private var state = State.WAKE_LISTEN
    private var ttsReady = false

    private val handler = Handler(Looper.getMainLooper())
    private val channelId = "jarvis_channel"
    private val notifId = 2001

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(notifId, buildNotification())

        setupTts()
        addGlowOverlay()

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            stopSelf()
            return
        }

        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(listener)
        startWakeListening()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        runCatching { recognizer.destroy() }
        runCatching { tts.stop(); tts.shutdown() }
        glowView?.let { runCatching { windowManager.removeView(it) } }
    }

    // ---------- Notification ----------

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openPending)
            .build()
    }

    // ---------- Glow overlay ----------

    private fun addGlowOverlay() {
        try {
            val view = EdgeGlowView(this)
            glowView = view
            val overlayType =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.START
            windowManager.addView(view, params)
        } catch (e: Exception) {
            glowView = null // overlay permission not granted - voice still works, just no visual glow
        }
    }

    // ---------- TTS ----------

    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts.language = Locale("hi", "IN")
                tts.setSpeechRate(0.95f)
                tts.setPitch(0.92f)
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                handler.post { onSpeakingDone() }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handler.post { onSpeakingDone() }
            }
        })
    }

    private var pendingAfterSpeak: (() -> Unit)? = null

    private fun speak(text: String, after: (() -> Unit)? = null) {
        pendingAfterSpeak = after
        if (ttsReady) {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            audioManager.setStreamVolume(
                android.media.AudioManager.STREAM_MUSIC,
                (audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) * 0.85).toInt(),
                0
            )
            val params = Bundle()
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_utt")
        } else {
            handler.postDelayed({ onSpeakingDone() }, 200)
        }
    }

    private fun onSpeakingDone() {
        val after = pendingAfterSpeak
        pendingAfterSpeak = null
        after?.invoke()
    }

    private fun vibrate() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    // ---------- Recognition ----------

    private fun wakeIntent(): Intent {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        return i
    }

    private fun commandIntent(): Intent {
        val i = wakeIntent()
        // Tuned pause timing so it neither cuts off mid-sentence nor waits too long
        i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1100)
        i.putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1100)
        i.putExtra("android.speech.extra.SPEECH_INPUT_MINIMUM_LENGTH_MILLIS", 1500)
        return i
    }

    private fun startWakeListening() {
        state = State.WAKE_LISTEN
        glowView?.stop()
        runCatching { recognizer.startListening(wakeIntent()) }
    }

    private fun startCommandListening() {
        state = State.AWAITING_COMMAND
        runCatching { recognizer.startListening(commandIntent()) }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            android.widget.Toast.makeText(this@JarvisService, "Sun raha hoon...", android.widget.Toast.LENGTH_SHORT).show()
        }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {
            // Intentionally ignored - only final results trigger anything,
            // so it never activates on a half-finished sentence.
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            val name = when (error) {
                SpeechRecognizer.ERROR_NETWORK -> "NETWORK"
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "NETWORK_TIMEOUT"
                SpeechRecognizer.ERROR_NO_MATCH -> "NO_MATCH"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "SPEECH_TIMEOUT"
                SpeechRecognizer.ERROR_AUDIO -> "AUDIO"
                SpeechRecognizer.ERROR_CLIENT -> "CLIENT"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "NO_PERMISSION"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "BUSY"
                SpeechRecognizer.ERROR_SERVER -> "SERVER"
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> "LANGUAGE_NOT_SUPPORTED"
                else -> "UNKNOWN($error)"
            }
            if (name != "NO_MATCH" && name != "SPEECH_TIMEOUT") {
                android.widget.Toast.makeText(this@JarvisService, "Error: $name", android.widget.Toast.LENGTH_SHORT).show()
            }
            when (state) {
                State.WAKE_LISTEN -> handler.postDelayed({ startWakeListening() }, 350)
                State.AWAITING_COMMAND -> {
                    state = State.BUSY
                    speak("Sir, sun nahi paya. 'Hey Jarvis' bolke dobara try kijiye.") {
                        glowView?.stop()
                        startWakeListening()
                    }
                }
                State.BUSY -> {}
            }
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull()?.trim() ?: ""
            val lower = text.lowercase(Locale.getDefault())

            when (state) {
                State.WAKE_LISTEN -> {
                    if (lower.contains("jarvis")) {
                        state = State.BUSY
                        vibrate()
                        glowView?.start()
                        speak("Ji Sir.") { startCommandListening() }
                    } else {
                        startWakeListening()
                    }
                }
                State.AWAITING_COMMAND -> {
                    state = State.BUSY
                    if (text.isBlank()) {
                        speak("Sir, sun nahi paya, dobara boliye.") { glowView?.stop(); startWakeListening() }
                    } else {
                        CommandProcessor.process(this@JarvisService, text) { response ->
                            HistoryStore.addHistory(this@JarvisService, text, response)
                            speak(response) { glowView?.stop(); startWakeListening() }
                        }
                    }
                }
                State.BUSY -> {}
            }
        }
    }
}
