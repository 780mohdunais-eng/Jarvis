package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * Simplified, reliable design: no continuous "always listening for a wake word"
 * loop (Android's SpeechRecognizer isn't built for that and it caused constant
 * mic open/close cycling). Instead: tap "Bolo Jarvis" (notification button or
 * in-app button) -> mic opens once, generous pause tolerance, you speak your
 * command, it responds, mic closes. Fully idle in between - no cycling, no clicks.
 */
class JarvisService : Service() {

    companion object {
        const val ACTION_LISTEN = "com.example.jarvis.ACTION_LISTEN"
    }

    private enum class State { IDLE, LISTENING, BUSY }

    private lateinit var windowManager: WindowManager
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var glowView: EdgeGlowView? = null
    private var state = State.IDLE
    private var ttsReady = false
    private var pendingUtterance: Pair<String, (() -> Unit)?>? = null

    private val handler = Handler(Looper.getMainLooper())
    private val channelId = "jarvis_channel"
    private val notifId = 2001

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(notifId, buildNotification("Tap 'Bolo Jarvis' jab command dena ho"))
        setupTts()
        addGlowOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_LISTEN) {
            triggerListen()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        runCatching { recognizer?.destroy() }
        runCatching { tts.stop(); tts.shutdown() }
        glowView?.let { runCatching { windowManager.removeView(it) } }
    }

    // ---------- Notification ----------

    private fun buildNotification(text: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val listenIntent = Intent(this, JarvisService::class.java).apply { action = ACTION_LISTEN }
        val listenPending = PendingIntent.getService(
            this, 1, listenIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_btn_speak_now, "Bolo Jarvis", listenPending)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(notifId, buildNotification(text))
    }

    // ---------- Glow overlay ----------

    private fun addGlowOverlay() {
        try {
            val view = EdgeGlowView(this)
            glowView = view
            val overlayType =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.START
            windowManager.addView(view, params)
        } catch (e: Exception) {
            glowView = null
        }
    }

    // ---------- TTS ----------

    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts.language = Locale("en", "IN")
                tts.setSpeechRate(0.92f)
                tts.setPitch(1.0f)
                pendingUtterance?.let { (text, after) ->
                    pendingUtterance = null
                    speak(text, after)
                }
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                handler.post { onSpeakingDone() }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handler.post { onSpeakingDone() }
            }
        })
    }

    private var pendingAfterSpeak: (() -> Unit)? = null

    private fun speak(text: String, after: (() -> Unit)? = null) {
        if (!ttsReady) {
            pendingUtterance = text to after
            return
        }
        pendingAfterSpeak = after
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        audioManager.setStreamVolume(
            android.media.AudioManager.STREAM_MUSIC,
            (audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) * 0.85).toInt(),
            0
        )
        val params = Bundle()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_utt")
    }

    private fun onSpeakingDone() {
        val after = pendingAfterSpeak
        pendingAfterSpeak = null
        after?.invoke()
    }

    private fun vibrate() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    // ---------- Trigger ----------

    private fun triggerListen() {
        if (state != State.IDLE) return
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            updateNotification("Mic permission nahi hai — app kholke do")
            return
        }
        vibrate()
        glowView?.start()
        state = State.BUSY
        speak("Ji Sir, boliye.") {
            startCommandListening()
        }
    }

    private fun commandIntent(): Intent {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        // generous pause tolerance - gives real thinking time instead of cutting off fast
        i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 3000)
        i.putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 3000)
        i.putExtra("android.speech.extra.SPEECH_INPUT_MINIMUM_LENGTH_MILLIS", 1500)
        return i
    }

    private fun startCommandListening() {
        state = State.LISTENING
        updateNotification("Sun raha hoon...")
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(applicationContext)
                recognizer!!.setRecognitionListener(listener)
            }
            recognizer!!.cancel()
            recognizer!!.startListening(commandIntent())
        } catch (e: Exception) {
            updateNotification("Error: ${e.message}")
            finishCycle()
        }
    }

    private fun finishCycle() {
        state = State.IDLE
        glowView?.stop()
        updateNotification("Tap 'Bolo Jarvis' jab command dena ho")
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { updateNotification("Sun raha hoon, boliye...") }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { updateNotification("Samajh raha hoon...") }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            val name = when (error) {
                SpeechRecognizer.ERROR_NETWORK -> "NETWORK"
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "NETWORK_TIMEOUT"
                SpeechRecognizer.ERROR_NO_MATCH -> "NO_MATCH"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "SPEECH_TIMEOUT"
                SpeechRecognizer.ERROR_AUDIO -> "AUDIO"
                SpeechRecognizer.ERROR_CLIENT -> "CLIENT"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "NO_PERMISSION"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "BUSY"
                SpeechRecognizer.ERROR_SERVER -> "SERVER"
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> "LANGUAGE_NOT_SUPPORTED"
                else -> "UNKNOWN($error)"
            }
            HistoryStore.addHistory(this@JarvisService, "[listen] error", name)
            speak("Sir, samajh nahi paya. Dobara 'Bolo Jarvis' dabaiye.") {
                finishCycle()
            }
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull()?.trim() ?: ""
            if (text.isBlank()) {
                speak("Sir, kuch suna nahi. Dobara try kijiye.") { finishCycle() }
                return
            }
            updateNotification("Suna: \"$text\"")
            CommandProcessor.process(this@JarvisService, text) { response ->
                HistoryStore.addHistory(this@JarvisService, text, response)
                speak(response) { finishCycle() }
            }
        }
    }
}
