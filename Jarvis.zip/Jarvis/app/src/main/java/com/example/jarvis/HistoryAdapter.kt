package com.example.jarvis

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Locale

class HistoryAdapter(private val items: List<HistoryEntry>) :
    RecyclerView.Adapter<HistoryAdapter.VH>() {

    class VH(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val you: TextView = view.findViewById(R.id.youSaid)
        val jarvis: TextView = view.findViewById(R.id.jarvisSaid)
        val time: TextView = view.findViewById(R.id.timestamp)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.you.text = "Aap: ${item.you}"
        holder.jarvis.text = "Jarvis: ${item.jarvis}"
        holder.time.text = SimpleDateFormat("d MMM, hh:mm a", Locale.getDefault()).format(item.time)
    }

    override fun getItemCount() = items.size
}
