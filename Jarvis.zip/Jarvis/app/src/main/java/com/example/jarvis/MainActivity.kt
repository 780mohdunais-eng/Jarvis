package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private var serviceRunning = false

    private val permissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.CAMERA
    )

    private val permissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnPermissions).setOnClickListener {
            val toRequest = permissions.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }.toMutableList()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    toRequest.add(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            if (toRequest.isEmpty()) {
                Toast.makeText(this, "Saari permissions already di hui hain", Toast.LENGTH_SHORT).show()
            } else {
                permissionLauncher.launch(toRequest.toTypedArray())
            }
        }

        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                Toast.makeText(this, "Overlay permission already diya hua hai", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            val pm = getSystemService(android.os.PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                startActivity(intent)
            } else {
                Toast.makeText(this, "Battery restriction already hati hui hai", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnToggleService).setOnClickListener {
            if (!serviceRunning) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Pehle microphone permission do", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                startService(Intent(this, JarvisService::class.java))
                serviceRunning = true
                updateStatus()
                Toast.makeText(this, "Jarvis on ho gaya — 'Hey Jarvis' bolke try karo", Toast.LENGTH_LONG).show()
            } else {
                stopService(Intent(this, JarvisService::class.java))
                serviceRunning = false
                updateStatus()
            }
        }

        val recycler = findViewById<RecyclerView>(R.id.historyList)
        recycler.layoutManager = LinearLayoutManager(this)
        loadHistory(recycler)

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        loadHistory(findViewById(R.id.historyList))
    }

    private fun loadHistory(recycler: RecyclerView) {
        recycler.adapter = HistoryAdapter(HistoryStore.getHistory(this))
    }

    private fun updateStatus() {
        val status = findViewById<TextView>(R.id.statusText)
        val btn = findViewById<Button>(R.id.btnToggleService)
        if (serviceRunning) {
            status.text = "Chal raha hai — 'Hey Jarvis' bolo"
            btn.text = "Jarvis Band Karo"
        } else {
            status.text = "Band hai"
            btn.text = "Jarvis Start Karo"
        }
    }
}
