# Jarvis (Android voice assistant)

Wake word "Hey Jarvis" (or just "Jarvis") activates it, edges of the screen glow soft
blue while it's listening/thinking, and it responds out loud in a "Sir"-addressing,
lightly witty Hinglish style.

## What it can do

- Open apps ("WhatsApp kholo")
- Google search ("cricket score search karo")
- Send a normal SMS ("Rahul ko message bhejo ghar aa raha hoon")
- Open WhatsApp with a message pre-typed to a contact (you tap Send yourself —
  WhatsApp doesn't allow apps to auto-send on your behalf)
- Dial a contact (opens the dialer, you tap the call button — apps aren't allowed
  to place calls without you confirming, only apps signed as the system dialer can)
- Time / date / battery percentage
- Flashlight on/off, volume up/down
- Basic calculator ("15 plus 27 kitna hota hai")
- Current city (via GPS + reverse geocoding) and current temperature (via the
  free Open-Meteo API, no key needed)
- Voice notes ("note kar lo doodh lana hai")
- Small talk / jokes / "kaise ho" — all pre-written responses, not a real AI brain

## Known, real limitations (not bugs)

- **Can't answer incoming calls by voice.** That needs a system-level permission
  (`MODIFY_PHONE_STATE`) that Android only grants to apps pre-installed by the
  phone maker — no sideloaded app can get it without rooting the device.
- **Doesn't recognize *your* voice specifically.** Android has no built-in,
  free speaker-verification API. It reacts to anyone saying "Jarvis".
- **Speech recognition isn't perfect.** It uses Android's built-in
  `SpeechRecognizer`, tuned to wait about 1.1s of silence before deciding
  you're done talking. It's tuned to reduce both "cuts me off early" and
  "waits forever" — but it will never be as good as Google Assistant/Siri's
  own models.
- **WhatsApp auto-send and voice call answering are policy-blocked**, not
  something more code can fix.

## Setup

1. Open in Android Studio (API 26+ device or emulator).
2. Run the app.
3. Tap **Permissions Do** and grant everything asked (mic, SMS, contacts,
   location, camera for flash).
4. Tap **Overlay Permission** and enable "Display over other apps" — this is
   only for the blue edge-glow visual; voice commands still work without it.
5. Tap **Jarvis Start Karo**.
6. Say "Hey Jarvis", wait for it to say "Ji Sir", then say your command.

## Tuning

- Wake word / command matching logic: `CommandProcessor.kt`
- Silence-timeout tuning for command capture: `JarvisService.kt`,
  `commandIntent()` (`SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS`, currently
  1100ms — raise it if it keeps cutting you off, lower it if it waits too long)
- Witty response lines: top of `CommandProcessor.kt`
